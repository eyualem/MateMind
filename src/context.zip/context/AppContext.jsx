// src/context/AppContext.jsx

import { createContext, useContext, useState, useEffect } from "react";
import { auth, db } from "../firebase/firebase.js";
import { onAuthStateChanged } from "firebase/auth";
import { doc, getDoc, setDoc } from "firebase/firestore";

// Create global app context
const AppContext = createContext();

// Provide context to all components
export const AppProvider = ({ children }) => {
  const [selectedTutor, setSelectedTutor] = useState(null);
  const [userName, setUserName] = useState("");
  const [currentUser, setCurrentUser] = useState(null);
  const [userProgress, setUserProgress] = useState(null);

  // ✅ Track whether auth check is still loading
  const [authLoading, setAuthLoading] = useState(true);

  // Listen to auth changes
  useEffect(() => {
  // Subscribe to Firebase authentication state changes
  const unsubscribe = onAuthStateChanged(auth, async (user) => {
    console.log("Firebase auth state changed:", user);

    if (user) {
      // Extract display name or default to "Player"
      const name = user.displayName || "Player";
      console.log("Logged in as:", name);

      // Update app context with user info
      setCurrentUser(user);
      setUserName(name);

      // Reference to the user's document in Firestore
      const userRef = doc(db, "users", user.uid);
      const userSnap = await getDoc(userRef);

      if (!userSnap.exists()) {
        // If user document doesn't exist, create a new one with default progress
        console.log("Creating new user progress...");
        const newProgress = {
          name,
          lastTutor: null,
          lastLessonIndex: 0,
          progress: {
            lessonPlan: [],
            completed: [],
          },
        };
        await setDoc(userRef, newProgress);
        setUserProgress(newProgress);
      } else {
        // If user document exists, load their progress
        console.log("Loaded existing user progress.");
        setUserProgress(userSnap.data());
      }
    } else {
      // No user is logged in — clear context
      console.log("No user logged in.");
      setCurrentUser(null);
      setUserName("");
      setUserProgress(null);
    }

    // Mark authentication loading as complete
    setAuthLoading(false);
    console.log("Auth loading complete.");
  });

  // Cleanup subscription on component unmount
  return () => unsubscribe();
}, []);


  return (
    <AppContext.Provider
      value={{
        selectedTutor,
        setSelectedTutor,
        userName,
        setUserName,
        currentUser,
        userProgress,
        setUserProgress,
        authLoading, // ✅ Expose loading flag
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

// Hook to use the context
export const useAppContext = () => useContext(AppContext);
