// Import to navigate across pages.
import { useNavigate } from "react-router-dom";

function PracticeMode() {
    const navigate = useNavigate();

    return <div></div>;
}

export default PracticeMode;  