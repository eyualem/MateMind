// Import to navigate across pages.
import { useNavigate } from "react-router-dom";

function MatchMode() {
    const navigate = useNavigate();

    return <div></div>;
}

export default MatchMode;  