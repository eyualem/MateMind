// src/screens/Welcome.jsx

import { useEffect } from "react";
import Button from "../components/Button";
import logo from "../assets/matemind-logo.png";
import { useNavigate } from "react-router-dom";
import { signInWithGoogle, getRedirectedUser } from "../firebase/firebaseAuth";
import { useAppContext } from "../context/AppContext";

function Welcome() {
  // Always call hooks at the top
  const navigate = useNavigate();
  const { currentUser, authLoading, setUserName } = useAppContext();

  // Auto-navigate if user is already logged in
  useEffect(() => {
  if (!authLoading && currentUser && location.pathname === "/") {
    setUserName(currentUser.displayName || "Player");
    navigate("/choose-tutor");
  }
  }, [authLoading, currentUser, navigate, setUserName, location.pathname]);


  // Handle redirect-based Google sign-in fallback
  useEffect(() => {
    getRedirectedUser()
      .then((user) => {
        if (user) {
          setCurrentUser(user);
          console.log("Redirected user:", user);
          // Set user name and navigate to tutor selection
          setUserName(user.displayName || "Player");
          navigate("/choose-tutor");
        }
      })
      .catch((error) => {
        console.error("Redirect sign-in failed:", error);
        // Optional: show a message or retry option
      });
  }, [navigate, setUserName]);

  // Trigger Google Sign-In (redirect flow)
  const handleGoogleLogin = () => {
    signInWithGoogle(); // This will redirect
  };

  // Guest login
  const handleGuestLogin = () => {
    setUserName("Guest");
    navigate("/choose-tutor");
  };

  // Show loading while auth is being checked
  if (authLoading) {
  return (
    <div className="min-h-screen bg-blue-900 text-white flex items-center justify-center">
      <div className="text-center text-lg font-medium">Authenticating...</div>
    </div>
  );
}


  // Show login options
  return (
    <div className="min-h-screen bg-blue-900 text-white flex flex-col items-center justify-center gap-8 px-4 text-center">
      <img
        src={logo}
        alt="MateMind Logo"
        className="w-24 h-24 rounded-lg bg-white p-2 mb-6 sm:w-28 sm:h-28"
      />

      <h1 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-light">
        Elevate your game, sharpen your mind
      </h1>

      <div className="flex flex-col gap-4 w-full max-w-xs">
        <Button onClick={handleGoogleLogin}>Continue with Google</Button>
        <Button
          className="bg-gray-200 text-blue-900"
          onClick={handleGuestLogin}
        >
          Continue as Guest
        </Button>
      </div>
    </div>
  );
}

export default Welcome;
