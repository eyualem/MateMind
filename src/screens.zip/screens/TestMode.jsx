// Import to navigate across pages.
import { useNavigate } from "react-router-dom";

function TestMode() {
    const navigate = useNavigate();

    return <div></div>;
}

export default TestMode;  